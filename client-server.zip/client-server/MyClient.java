package com.drishti.hiring.solution;

import java.util.List;
import java.util.Random;

import com.drishti.hiring.server01.AbstractMyClient;
import com.drishti.hiring.server01.MyMessage;

public class MyClient extends AbstractMyClient {


	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// do call the init() method
		try {
			init(null);
		} catch (Exception e1) {
			e1.printStackTrace();
			return;
		}

		/*
		 * The following is a sample code that demonstrates
		 * - how to construct a message
		 * - how to transmit a message
		 * - how to receive a message
		 * 
		 * Write your code after this
		 */
		
		// Generate a name for this client. It is not necessary to do so.
		// This sample just uses the name in the text that is transmitted
		String name = generateName();
		System.out.println("Started, client name: " + name);

		// declare some constants such as message categories
		final int MESSAGE_TYPE_CHAT = 1;

		
		while (true) {

			// generate some random messages and send
			String someText = generateARandomMessage(name);

			// this is how you construct a message
			MyMessage myMessageOutgoing = new MyMessage(MESSAGE_TYPE_CHAT,
					someText);

			// this is how you send a message
			writeMessage(myMessageOutgoing);

			// this is how you receive a message
			List<MyMessage> myMessages = readIncomingMessages();

			// you can simply iterate over the received messages
			System.out.println("i " + name + " received " + myMessages.size()
					+ " messages from the server");
			for (MyMessage myMessage : myMessages) {
				System.out.println("" + myMessage.getText());
			}

			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		/*
		 * Write your code above this
		 */

	}

	private static String generateName() {
		Random random = new Random();
		String name = "client" + random.nextInt();
		return name;
	}

	private static String generateARandomMessage(String name) {
		Random someRandom = new Random();
		int nextInt = someRandom.nextInt();
		String someText = "hello" + "__" + name + "__" + nextInt;
		return someText;
	}

}
